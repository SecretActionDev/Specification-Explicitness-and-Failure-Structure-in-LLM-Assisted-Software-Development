

"""
Stub file for the is allocation feasible exercise.

Implement the function `is_allocation_feasible` to  Determine whether a set of resource requests can be satisfied 
given limited capacities. Take int account any possible constraints. See the lab handout
for full requirements.
"""
    
from typing import Dict, List, Union

Number = Union[int, float]


def is_allocation_feasible(
    resources: Dict[str, Number],
    requests: List[Dict[str, Number]]
) -> bool:
    """
    Determine whether a set of resource requests can be satisfied given limited capacities.

    Args:
        resources : Dict[str, Number], Mapping from resource name to total available capacity.
        requests : List[Dict[str, Number]], List of requests. Each request is a mapping from resource name to the amount required.

    Returns:
        True if the allocation is feasible, False otherwise.

    """
    for request in requests:
        if not isinstance(request, dict):
            raise ValueError("Each request must be a dictionary")
    
    total_demand: Dict[str, Number] = {}
    
    for request in requests:
        for resource_name, amount in request.items():
            if resource_name in total_demand:
                total_demand[resource_name] += amount
            else:
                total_demand[resource_name] = amount
    
    for resource_name, demand in total_demand.items():
        if resource_name not in resources:
            return False
        
        if demand > resources[resource_name]:
            return False
    
    return True