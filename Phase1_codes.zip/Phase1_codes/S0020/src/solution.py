
from typing import Dict, List, Union

Number = Union[int, float]


def is_allocation_feasible(
    resources: Dict[str, Number],
    requests: List[Dict[str, Number]]
) -> bool:
    if not isinstance(resources, dict):
        raise ValueError("The resources must be a dictionary")

    total_usage: Dict[str, Number] = {key: 0 for key in resources}

    for request in requests:
        if not isinstance(request, dict):
            raise ValueError("Each request must be a dict")

        for name, amount in request.items():
            if name not in resources:
                return False
            if not isinstance(amount, (int, float)):
                raise ValueError("Requested amount must be a number")

            total_usage[name] += amount

    for name, used in total_usage.items():
        if used > resources[name]:
            return False

    has_leftover = any((resources[name] - used) > 0 for name, used in total_usage.items())
    if not has_leftover:
        return False

    return True
