
"""
Stub file for the meeting slot suggestion exercise.

Implement the function `suggest_slots` to return a list of valid meeting start times
on a given day, taking into account working hours, and possible specific constraints. See the lab handout
for full requirements.
"""
from typing import List, Dict


def suggest_slots(
    events: List[Dict[str, str]], meeting_duration: int, day: str
) -> List[str]:
    """
    Suggest possible meeting start times for a given day.

    Args:
        events: List of dicts with keys {"start": "HH:MM", "end": "HH:MM"}
        meeting_duration: Desired meeting length in minutes
        day: Three-letter day abbreviation (e.g., "Mon", "Tue", ... "Fri")

    Returns:
        List of valid start times as "HH:MM" sorted ascending
    """
    day = 0
    timeIncrement = 15
    postBufferTime = 15
    output = []
    bookedTimes = events[::]
    bookedTimes.append({"start": "12:00", "end": "12:45"})
    bookedTimes.append({"start": "00:00", "end": "08:45"})
    bookedTimes.append({"start": "17:00", "end": "23:59"})

    for booked in bookedTimes:
        day = day | _convertEventToBinary(booked, postBufferTime)

    for i in range(0, 1440 - meeting_duration, timeIncrement):
        if not (day & (_convertMeetingDurationToBinary(meeting_duration) << i)):
            output.append(_convertNumberToTime(meeting_duration, i))

    return output[::-1]  # reverse because it is decrementing



def _convertEventToBinary(event: Dict[str, str], postBuffer: int) -> int:
    start = int(event["start"][:2]) * 60 + int(event["start"][3:])
    end = int(event["end"][:2]) * 60 + int(event["end"][3:]) + postBuffer
    if end > 1440:
        end = 1440
    duration = end - start
    bits = (1 << duration) - 1
    bits = bits << (1440 - end)
    return bits


def _convertMeetingDurationToBinary(duration: int) -> int:
    return (1 << duration) - 1


def _convertNumberToTime(duration: int, number: int) -> str:
    minutes = 1440 - duration - number
    return f"{(minutes//60):02d}:{(minutes%60):02d}"





