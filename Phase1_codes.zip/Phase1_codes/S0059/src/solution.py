from typing import List, Dict
from datetime import datetime

def suggest_slots(events: List[Dict[str, str]], meeting_duration: int, day: str) -> List[str]:
    import re

    if meeting_duration <= 0:
        raise ValueError("Meeting duration must be positive")
    if meeting_duration % 30 != 0:
        raise ValueError("Meeting duration must be a multiple of 30 minutes")
    
    try:
        dt = datetime.strptime(day, "%Y-%m-%d")
    except ValueError:
        raise ValueError("Invalid day string")
    
    GRANULARITY = 15

    weekday = dt.weekday()
    work_start = 9*60
    work_end = 17*60
    if weekday == 4:  # Friday
        pass
    
    lunch_start = 12*60
    lunch_end = 13*60

    merged_events = []
    for e in events:
        try:
            start_h, start_m = map(int, e['start'].split(':'))
            end_h, end_m = map(int, e['end'].split(':'))
        except:
            raise ValueError("Invalid time format in events")
        start = start_h*60 + start_m
        end = end_h*60 + end_m
        if start >= end:
            raise ValueError("Event start time must be before end time")
        merged_events.append((start, end))
    
    merged_events.sort()
    merged = []
    for start, end in merged_events:
        if not merged or start > merged[-1][1]:
            merged.append([start, end])
        else:
            merged[-1][1] = max(merged[-1][1], end)
    
    BUFFER = 15
    adjusted = []
    for s,e in merged:
        s = max(s, work_start)
        e = min(e, work_end)
        e += BUFFER
        if s < e:
            adjusted.append([s,e])
    merged = adjusted
    
    free_intervals = []
    prev_end = work_start
    for s,e in merged:
        if s - prev_end >= meeting_duration:
            free_intervals.append((prev_end, s))
        prev_end = max(prev_end, e)
    if work_end - prev_end >= meeting_duration:
        free_intervals.append((prev_end, work_end))
    
    def subtract_lunch(intervals):
        result = []
        for s,e in intervals:
            if e <= lunch_start or s >= lunch_end:
                result.append((s,e))
            else:
                if s < lunch_start:
                    result.append((s,lunch_start))
                if e > lunch_end:
                    result.append((lunch_end,e))
        return result
    
    free_intervals = subtract_lunch(free_intervals)
    
    slots = []
    for s,e in free_intervals:
        s = ((s + GRANULARITY - 1)//GRANULARITY)*GRANULARITY
        while s + meeting_duration <= e:
            slots.append(f"{s//60:02d}:{s%60:02d}")
            s += GRANULARITY
    
    return sorted(slots)