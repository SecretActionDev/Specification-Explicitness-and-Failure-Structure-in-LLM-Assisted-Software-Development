from typing import Dict, List, Union, Any

Number = Union[int, float]

def is_allocation_feasible(
    resources: Dict[str, Number],
    requests: List[Dict[str, Number]]
) -> bool:
    total_request = {r: 0 for r in resources}
    
    for req in requests:
        for r_type, amount in req.items():
            if r_type not in resources:
                return False
            if amount < 0:
                return False
            total_request[r_type] += amount
    
    for r_type, total in total_request.items():
        if total > resources[r_type]:
            return False
    
    return True